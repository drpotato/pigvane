(function() {
  Pigvane.Classes.Achievements = (function() {
    function Achievements(game) {
      var achievementCallback, endCallback;
      this.game = game;
      this.numberAchievements = 0;
      this.achievementList = {
        'free': {
          'name': 'The First One\'s Free',
          'img': 'achievement_first_free'
        },
        'cat_playable': {
          'name': 'Even Cats Can Play',
          'img': 'achievement_cats_can_play'
        },
        'first_steps': {
          'name': 'First Steps',
          'img': 'achievement_first_steps'
        },
        '3_lives': {
          'name': 'You Only Live Thrice',
          'img': 'achievement_3_lives'
        },
        'dlc': {
          'name': 'I Love Horse Armor',
          'img': 'achievement_dlc'
        },
        'kill_1': {
          'name': 'Say Hello To My Little Friend!',
          'img': 'achievement_first_blood'
        },
        'pacifist': {
          'name': 'It\'s All Sunshine and Rainbows',
          'img': 'achievement_sunshine_rainbows'
        },
        'suburbs_complete': {
          'name': 'Concrete Jungle',
          'img': 'achievement_city_complete'
        },
        'candyland_complete': {
          'name': 'Copyright Violation',
          'img': 'achievement_copyright_violation'
        },
        'old_man_kill': {
          'name': 'Euthanasia Enthusiast',
          'img': 'achievement_kill_old_man'
        },
        'old_man_help': {
          'name': 'Let There Be Sight!',
          'img': 'achievement_help_old_man'
        },
        'kid_kill': {
          'name': 'Yuck 9mm flavour',
          'img': 'achievement_kill_kid'
        },
        'kid_help': {
          'name': 'Diabetes Enabler',
          'img': 'achievement_help_kid'
        },
        'pig_owner_kill': {
          'name': 'Makin\' some bacon',
          'img': 'achievement_kill_pig_owner'
        },
        'pig_owner_help': {
          'name': 'Lipstick on a Pig',
          'img': 'achievement_help_pig_owner'
        },
        'monk_kill': {
          'name': 'No Yin, Only Yang',
          'img': 'achievement_kill_monk'
        },
        'monk_help': {
          'name': 'Enlightened',
          'img': 'achievement_help_monk'
        },
        'crusher_kill': {
          'name': 'Better Lawyer Up',
          'img': 'achievement_kill_candy_crusher'
        },
        'crusher_help': {
          'name': 'Delicious!',
          'img': 'achievement_help_candy_crusher'
        },
        'cat_kill': {
          'name': 'Schrodinger\'s cat',
          'img': 'achievement_kill_cat'
        },
        'cat_help': {
          'name': 'Time For Adventure!',
          'img': 'achievement_help_cat'
        },
        'sick_pig_kill': {
          'name': 'Green Eggs and Ham',
          'img': 'achievement_kill_sick_pig'
        },
        'sick_pig_help': {
          'name': 'At Least There\'s No Birds',
          'img': 'achievement_help_sick_pig'
        },
        'ninja_kill': {
          'name': 'Gun Beats Sword',
          'img': 'achievement_kill_fruit_ninja'
        },
        'ninja_help': {
          'name': 'Fruit Massacre',
          'img': 'achievement_help_fruit_ninja'
        },
        'red_kill': {
          'name': 'Lamb to the Slaughter',
          'img': ''
        },
        'red_help': {
          'name': 'Wolf in Sheep\'s Clothes',
          'img': ''
        },
        'squirrel_kill': {
          'name': 'Part of the Janitor\'s Collection',
          'img': ''
        },
        'squirrel_help': {
          'name': 'What Innuendo?',
          'img': ''
        },
        'yogi_kill': {
          'name': 'Bear got a Boo-boo',
          'img': ''
        },
        'yogi_help': {
          'name': 'Pic-a-nic Basket',
          'img': ''
        },
        'sonic_kill': {
          'name': 'No Rings Left',
          'img': ''
        },
        'sonic_help': {
          'name': 'Running Like The Wind',
          'img': ''
        },
        'human_end': {
          'name': 'Loneliness',
          'img': 'achievement_finish_human'
        },
        'cat_end': {
          'name': 'Indifference',
          'img': 'achievement_cats_can_play'
        },
        'wind_end': {
          'name': 'Concordance',
          'img': 'achievement_finish_wind'
        },
        'pig_end': {
          'name': 'Greed',
          'img': 'achievement_finish_pig'
        }
      };
      achievementCallback = function() {
        return Pigvane.Main.achievements.grant('free');
      };
      setTimeout(achievementCallback, 1000);
      endCallback = function() {
        Pigvane.levelController.currentLevelIndex = 2;
        return Pigvane.levelController.loadLevel();
      };
      achievementCallback = function() {
        if (Pigvane.Main.dude.cat) {
          Pigvane.Main.achievements.grant('cat_playable');
          return setTimeout(endCallback, 3000);
        }
      };
      setTimeout(achievementCallback, 30000);
    }

    Achievements.prototype.grant = function(achievementName) {
      var achievement, achievementData, background, callback, image, imageSprite, imageWrapperSprite, text, textName, textSprite, textTitle;
      if (!this.achievementList[achievementName]['granted']) {
        this.achievementList[achievementName]['granted'] = true;
        this.numberAchievements += 1;
        achievementData = this.achievementList[achievementName];
        achievement = this.game.add.group();
        achievement.height = 100;
        achievement.width = 350;
        achievement.x = this.game.width - achievement.width;
        achievement.y = this.game.height;
        background = achievement.create(0, 0, 'achievement_background');
        imageWrapperSprite = this.game.add.sprite(0, 0);
        imageSprite = this.game.add.sprite(25, 25, achievementData['img']);
        imageWrapperSprite.addChild(imageSprite);
        textSprite = this.game.add.sprite(0, 0);
        textSprite.fixedToCamera = true;
        textTitle = this.game.add.bitmapText(100, 10, 'Achievement Unlocked!', {
          'font': '16pt pixelFont',
          'fill': 'white',
          'wordWrap': true,
          'wordWrapWidth': 100
        });
        textName = this.game.add.bitmapText(100, 40, achievementData['name'], {
          'font': '12pt pixelFont',
          'fill': 'white',
          'wordWrap': true,
          'wordWrapWidth': 100
        });
        textSprite.addChild(textTitle);
        textSprite.addChild(textName);
        text = achievement.add(textSprite);
        image = achievement.add(imageWrapperSprite);
        background.fixedToCamera = true;
        text.fixedToCamera = true;
        image.fixedToCamera = true;
        this.game.add.tween(achievement).to({
          y: this.game.height - achievement.height * this.numberAchievements
        }, 1000, Phaser.Easing.Linear.None, true);
        callback = function() {
          var tween;
          tween = Pigvane.Main.game.add.tween(achievement).to({
            alpha: 0
          }, 3000, Phaser.Easing.Linear.None, true);
          return tween.onComplete.add(function() {
            achievement.destroy();
            return Pigvane.Main.achievements.numberAchievements -= 1;
          });
        };
        return setTimeout(callback, 3000);
      }
    };

    return Achievements;

  })();

}).call(this);

(function() {
  Pigvane.States.Boot = (function() {
    function Boot(game) {
      this.game = game;
    }

    Boot.prototype.preload = function() {
      return this.game.load.image('preload', 'res/barscaled.png');
    };

    Boot.prototype.create = function() {
      return this.game.state.start('Preloader');
    };

    return Boot;

  })();

}).call(this);

(function() {
  Pigvane.Classes.DLC = (function() {
    function DLC(game) {
      this.game = game;
      this.choosing = false;
    }

    DLC.prototype.popup = function() {
      var bg, dialog, text, textSprite, waitForIt;
      if (!this.choosing) {
        this.choosing = true;
        dialog = this.game.add.group();
        dialog.x = 148;
        dialog.y = 80;
        bg = dialog.create(0, 0, 'dialog');
        bg.fixedToCamera = true;
        textSprite = this.game.add.sprite();
        text = this.game.add.text(60, 40, 'Would you like to buy the DLC to continue?\n                1. Yes    2. Ok', {
          'font': '30px Arial',
          'fill': 'black',
          'wordWrap': true,
          'wordWrapWidth': 450
        });
        textSprite.addChild(text);
        textSprite.fixedToCamera = true;
        dialog.add(textSprite);
        waitForIt = function() {
          if (Pigvane.Main.game.input.keyboard.isDown(49)) {
            dialog.destroy();
            return Pigvane.Main.dlc.purchase();
          } else if (Pigvane.Main.game.input.keyboard.isDown(50)) {
            dialog.destroy();
            return Pigvane.Main.dlc.purchase();
          } else {
            return setTimeout(waitForIt, 100);
          }
        };
        return waitForIt();
      }
    };

    DLC.prototype.purchase = function() {
      return Pigvane.Main.dude.x = 8192;
    };

    return DLC;

  })();

}).call(this);

(function() {
  Pigvane.Classes.Dialog = (function() {
    function Dialog(game, text) {
      this.game = game;
      this.text = text != null ? text : "Hey";
      this.dialogList = {
        'dialog_template': {
          'request': 'Help me!',
          'options': '1. Yes.\n2. No\n3. Kill them.'
        },
        'old_man': {
          'request': '"Oh where are my glasses? I had them this morning..."',
          'options': '1. Tell him they\'re on his head.\n2. Ignore him and walk away.\n3. Put him out of his misery.'
        },
        'ice_cream_kid': {
          'request': '*sob* "My ICE CREEEEAM WAAAAHH!" *sob*',
          'options': '1. "Kid, you don\'t need to scream for ice cream, here\'s a dollar."\n2. Let out a shrill scream and walk away.\n3. Give the kid a 9mm brain freeze.'
        },
        'girl_with_pig': {
          'request': '"My little piggy is just so adorable."',
          'options': '1. Give her a pretty pink bow for her pig.\n2. Stare the pig in the eye and say "I love you." then leave.\n3. Make some bacon.'
        },
        'candy_crusher': {
          'request': '"Crushing candy(tm) all day long, if only I could do this from my phone, then people would follow my saga(tm)."',
          'options': '1. Shop him to the app store.\n2. Leave before anyone takes legal action.\n3. Crush(tm) his dreams.'
        },
        'cake_cat': {
          'request': '"Have you seen Fionna anywhere? Oh I hope she took a jacket otherwise she\'ll get frozen solid!"',
          'options': '1. "Maybe she went to see the gumball guy."\n2. "No."\n3. "I\'ll freeze you solid."'
        },
        'angry_pig': {
          'request': '"Ooohh... * belch* I shouldn\'t have eaten so much candy(tm)."',
          'options': '1. Offer your sympathy and a pat on the back.\n2. Eat some candy(tm) infront of him.\n3. "I\'ve always wondered what green ham tastes like... Now I just need some green eggs."'
        },
        'fruit_ninja': {
          'request': '"Fruit has no place in candy(tm) land. Their vitamins and minerals must be sliced to pieces."',
          'options': '1. Join in the fruit massacre.\n2. "Nope."\n3. Kill the ninja and begin a fruit uprising.'
        },
        'red_riding_hood': {
          'request': '"Wow grandma, what big teeth you have!"\n "All the better to eat yo.. eat with."',
          'options': '1. "That\'s clearly a wolf little girl"\n2. Pull up a chair and watch.\n3. "That cave looks like a nice private eating spot."'
        },
        'squirrell': {
          'request': '"I love me some good nuts! Especially the big, firm ones."',
          'options': '1. "There\'s a juicy pair over there."\n2. Back away slowly.\n3. Feed him his own nuts.'
        },
        'yogi_bear': {
          'request': '"Oooh I\'m starving! It\'s a tough life foraging for food."',
          'options': '1. Point out the unguarded picnic basket in the distance.\n2. Eat a sandwich.\n3. Panic and shoot the bear before he mauls you.'
        },
        'sonic': {
          'request': '"I used to run fast, but without my lucky sneakers I\'ll never run like I used to."',
          'options': '1. "You never needed the sneakers. \'You could run fast all day long\'"\n2. "Gotta go fast!"\n3. "I don\t care for your pumped up kicks, you can\'t outrun my gun!"'
        },
        'monk': {
          'request': '"Karma is a big deal y\'know. If you are a good person, you\'ll get a good ending, but if you\'re evil... well, you don\'t wanna know."',
          'options': '1. "Peace be with you, brother" \n2. Look strangely at the monk and back away. \n3. "Convert this!"'
        }
      };
    }

    Dialog.prototype.popup = function(dialogName, npc) {
      var bg, callback, dialog, text, textSprite;
      dialog = this.game.add.group();
      dialog.x = 148;
      dialog.y = 80;
      dialog.alpha = 0;
      bg = dialog.create(0, 0, 'dialog');
      bg.fixedToCamera = true;
      textSprite = this.game.add.sprite();
      text = this.game.add.text(40, 40, this.dialogList[dialogName]['request'], {
        'font': '30px Arial',
        'fill': 'black',
        'wordWrap': true,
        'wordWrapWidth': 550
      });
      textSprite.addChild(text);
      textSprite.fixedToCamera = true;
      dialog.add(textSprite);
      this.game.add.tween(dialog).to({
        y: 100,
        alpha: 1
      }, 1000, Phaser.Easing.Linear.None, true);
      callback = function() {
        var tween;
        tween = Pigvane.Main.game.add.tween(dialog).to({
          y: 80,
          alpha: 0
        }, 2000, Phaser.Easing.Linear.None, true);
        return tween.onComplete.add(function() {
          var waitForIt;
          dialog.destroy();
          dialog = Pigvane.Main.game.add.group();
          dialog.x = 148;
          dialog.y = 80;
          dialog.alpha = 0;
          bg = dialog.create(0, 0, 'dialog');
          bg.fixedToCamera = true;
          textSprite = Pigvane.Main.game.add.sprite();
          text = Pigvane.Main.game.add.text(40, 40, Pigvane.Main.dialog.dialogList[dialogName]['options'], {
            'font': '30px Arial',
            'fill': 'black',
            'wordWrap': true,
            'wordWrapWidth': 550
          });
          textSprite.addChild(text);
          textSprite.fixedToCamera = true;
          dialog.add(textSprite);
          Pigvane.Main.game.add.tween(dialog).to({
            y: 100,
            alpha: 1
          }, 1000, Phaser.Easing.Linear.None, true);
          waitForIt = function() {
            if (Pigvane.Main.game.input.keyboard.isDown(49)) {
              Pigvane.Main.game.add.tween(dialog).to({
                y: 80,
                alpha: 0
              }, 2000, Phaser.Easing.Linear.None, true);
              return npc.sendResponse('1');
            } else if (Pigvane.Main.game.input.keyboard.isDown(50)) {
              Pigvane.Main.game.add.tween(dialog).to({
                y: 80,
                alpha: 0
              }, 2000, Phaser.Easing.Linear.None, true);
              return npc.sendResponse('2');
            } else if (Pigvane.Main.game.input.keyboard.isDown(51)) {
              Pigvane.Main.game.add.tween(dialog).to({
                y: 80,
                alpha: 0
              }, 2000, Phaser.Easing.Linear.None, true);
              return npc.sendResponse('3');
            } else if (Pigvane.Main.game.input.keyboard.isDown(Phaser.Keyboard.LEFT)) {
              Pigvane.Main.game.add.tween(dialog).to({
                y: 80,
                alpha: 0
              }, 2000, Phaser.Easing.Linear.None, true);
              return npc.sendResponse('reset');
            } else if (Pigvane.Main.game.input.keyboard.isDown(Phaser.Keyboard.RIGHT)) {
              Pigvane.Main.game.add.tween(dialog).to({
                y: 80,
                alpha: 0
              }, 2000, Phaser.Easing.Linear.None, true);
              return npc.sendResponse('reset');
            } else {
              return setTimeout(waitForIt, 50);
            }
          };
          return waitForIt();
        });
      };
      return setTimeout(callback, 3000);
    };

    return Dialog;

  })();

}).call(this);

(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Pigvane.Classes.Dude = (function(_super) {
    __extends(Dude, _super);

    function Dude(game, x, y) {
      this.game = game;
      Dude.__super__.constructor.call(this, game, x, y, 'dude');
      this.name = 'dude';
      this.moved = false;
      this.kills;
      this.specialKills = 0;
      this.helps = 0;
      this.ignores = 0;
      this.cat = true;
      this.animations.add('right', [0, 1, 2, 3]);
      this.animations.add('jump', [4, 5, 6, 7, 8, 9]);
      this.animations.add('drawn', [10, 11, 12, 13]);
      this.animations.play('right', 16, true);
      this.body.setSize(32, 32, 0, 0);
      this.anchor.setTo(0.5, 0.5);
      this.body.collideWorldBounds = true;
      this.cursors = this.game.input.keyboard.createCursorKeys();
      this.nextBullet = 0;
      this.facing = 'right';
      this.body.gravity.y = 10;
      this.lives = 3;
      this.health = 10;
      this.gunDrawn = false;
      this.aggro = 1;
      this.game.input.keyboard.addKey(Phaser.Keyboard.Z).onDown.add(this.switchDrawnState, this);
    }

    Dude.prototype.update = function() {
      var facing, soundCallback;
      this.game.physics.collide(this, Pigvane.Main.mainLayer);
      if (this.game.input.keyboard.isDown(Phaser.Keyboard.D)) {
        Pigvane.Main.dlc.popup();
      }
      this.vStep = 50;
      this.velocity = 200;
      this.jumpVelocity = 300;
      if (this.game.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR)) {
        this.velocity = 300;
      }
      if (this.game.input.keyboard.isDown(Phaser.Keyboard.X)) {
        this.velocity = 100;
      }
      facing = this.facing;
      if (this.cursors.left.isDown && (Math.abs(this.body.velocity.x) + this.vStep <= this.velocity || this.body.velocity.x >= 0)) {
        this.body.velocity.x -= this.vStep;
        facing = 'left';
      } else if (this.cursors.right.isDown && (Math.abs(this.body.velocity.x) + this.vStep <= this.velocity || this.body.velocity.x <= 0)) {
        this.body.velocity.x += this.vStep;
        facing = 'right';
      }
      if (this.cursors.up.isDown && this.body.touching.down) {
        this.body.velocity.y = -this.jumpVelocity;
        this.canceledJump = false;
        soundCallback = function() {
          return Pigvane.Main.soundManager.sfxJump.play();
        };
        setTimeout(soundCallback, 150);
      }
      if (this.cursors.up.isUp && this.canceledJump === false && this.body.velocity.y <= 0) {
        this.body.velocity.y = 0;
        this.canceledJump = true;
      }
      if (this.cursors.up.isDown || this.cursors.right.isDown || this.cursors.left.isDown || this.game.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR || this.game.input.keyboard.isDown(Phaser.Keyboard.X))) {
        this.cat = false;
      }
      if (this.facing === 'right') {
        this.scale.x = 1;
      } else if (this.facing === 'left') {
        this.scale.x = -1;
      }
      if (this.game.input.keyboard.isDown(Phaser.Keyboard.V)) {
        this.damage();
      }
      if (!this.cursors.left.isDown && !this.cursors.right.isDown && !this.cursors.up.isDown) {
        if (Math.abs(this.body.velocity.x) < 50) {
          this.body.velocity.x = 0;
        }
        if (this.body.velocity.x > 0) {
          this.body.velocity.x -= 50;
        } else if (this.body.velocity.x < 0) {
          this.body.velocity.x += 50;
        }
      }
      if (this.game.input.keyboard.isDown(Phaser.Keyboard.X) && this.gunDrawn === true) {
        this.fire();
        Pigvane.Main.soundManager.sfxGunshotPlayer.play();
      } else {
        this.facing = facing;
      }
      if (this.body.velocity.x === 0 && this.body.velocity.y === 0) {
        this.animations.stop();
      } else {
        if (this.gunDrawn === true) {
          this.animations.play('drawn', 16, true);
        } else {
          this.animations.play('right', 16, true);
        }
      }
      this.updateAchievements();
      Pigvane.Main.bgScroll.tilePosition.x = this.game.world.camera.x / 2.5;
      Pigvane.Main.bgbgScroll.tilePosition.x = this.game.world.camera.x / 5;
      return true;
    };

    Dude.prototype.switchDrawnState = function() {
      this.gunDrawn = !this.gunDrawn;
      if (this.gunDrawn === true) {
        return this.animations.frame = 10;
      } else {
        return this.animations.frame = 0;
      }
    };

    Dude.prototype.hitByNPC = function(obj1, obj2) {
      obj2.kill();
      return Pigvane.Main.dude.damage();
    };

    Dude.prototype.fire = function() {
      var bullet, callback;
      if (this.game.time.now > this.nextBullet) {
        bullet = Pigvane.Main.bullets.getFirstExists(false);
        if (bullet) {
          bullet.reset(this.x, this.y);
          bullet.animations.frame = 1;
          callback = function() {
            bullet.animations.stop();
            bullet.animations.play('repeat', 4, true);
            return bullet.animations.frame = bullet.x % 2 === 0 ? 2 : 3;
          };
          setTimeout(callback, 17);
          if (this.facing === 'right') {
            bullet.body.velocity.x = 1000;
            if (Math.abs(this.body.velocity.x - 100) <= this.velocity) {
              this.body.velocity.x -= 100;
            }
          } else if (this.facing === 'left') {
            bullet.body.velocity.x = -1000;
            if (Math.abs(this.body.velocity.x - 100) <= this.velocity) {
              this.body.velocity.x += 100;
            }
          }
          bullet.body.velocity.x += this.game.rnd.integerInRange(-100, 100);
          bullet.body.velocity.y += this.game.rnd.integerInRange(-40, 40);
        }
        return this.nextBullet = this.game.time.now + 80;
      }
    };

    Dude.prototype.damage = function() {
      this.health -= 1;
      if (this.health === 0) {
        Pigvane.Main.soundManager.sfxDeathScream.play();
        this.respawn();
        this.health = 10;
        this.lives--;
        Pigvane.Main.healthBar.removeLife();
        if (this.lives === 0) {
          console.log(this.game.state.states);
          this.game.state.start('Restart');
        }
      }
      return Pigvane.Main.healthBar.update();
    };

    Dude.prototype.respawn = function() {
      this.x = this.game.world.camera.x + 50;
      return this.y = 500;
    };

    Dude.prototype.updateAchievements = function() {
      if (!this.moved && this.body.velocity.x !== 0) {
        this.moved = true;
        Pigvane.Main.achievements.grant('first_steps');
      }
      if (this.specialKills === 1) {
        return Pigvane.Main.achievements.grant('kill_1');
      }
    };

    return Dude;

  })(Phaser.Sprite);

}).call(this);

(function() {
  Pigvane.Classes.End = (function() {
    function End(game) {
      this.game = game;
      this.endings = [
        {
          'img': '',
          'msg': 'Here your journey ends\n and yet again, nobody is there for you.\n Not one soul even acknowledged you.\n\n Did you really make a difference, or did you just think you did?'
        }, {
          'img': '',
          'msg': 'Right and wrong...\n Just words from different perspectives.\n In the end, did any of it matter? \n\n Probably not'
        }, {
          'img': '',
          'msg': 'Your journey has reached it\'s conclusion.\n Your actions changed the world\n but in the end, there is only you. \n\nAnd you are alone.'
        }, {
          'img': '',
          'msg': 'The end was always an inevitability.\nYour journey was full of choice,\nyet you remain the same. \n\nWhat does the journey matter if nothing has changed?'
        }
      ];
    }

    End.prototype.preload = function() {
      this.game.stage.backgroundColor = "#000000";
      this.game.add.bitmapText(300, 100, 'End', {
        'font': '128px pixelFont',
        'fill': 'white'
      });
      this.msg = this.endings[this.game.rnd.integerInRange(0, 3)].msg;
      return this.game.add.bitmapText(250, 300, this.msg, {
        font: '16px pixelFont',
        fill: 'white',
        align: 'center',
        width: '896px'
      });
    };

    End.prototype.start = function() {
      if (Pigvane.Main.dude.kills === 0 && Pigvane.Main.dude.specialKills === 0) {
        Pigvane.Main.achievements.grant('pacifist');
      }
      return this.ending = this.endings[this.game.rnd.integerInRange(0, 4)];
    };

    return End;

  })();

}).call(this);

(function() {
  Pigvane.Classes.HealthOverlay = (function() {
    function HealthOverlay(game) {
      var healthLeft, heart, heartContainer, i, livesLeft, sprite, _i;
      this.game = game;
      sprite = this.game.add.sprite(0, 0);
      sprite.fixedToCamera = true;
      this.livesTitle = 'Lives :';
      livesLeft = Pigvane.Main.dude.lives;
      this.livesText = this.game.add.bitmapText(0, 0, this.livesTitle, {
        font: '28px pixelFont'
      });
      this.hearts = this.game.add.group();
      this.hearts.x = 120;
      this.hearts.y = 10;
      this.heartsArray = [];
      for (i = _i = 0; 0 <= livesLeft ? _i < livesLeft : _i > livesLeft; i = 0 <= livesLeft ? ++_i : --_i) {
        heartContainer = this.game.add.sprite(0, 0);
        heart = this.game.add.sprite(40 * i, 0, 'lives');
        heart.animations.add('main', [0, 1, 2, 3]);
        heart.animations.play('main', 4, true);
        heartContainer.addChild(heart);
        heartContainer.fixedToCamera = true;
        this.hearts.add(heartContainer);
        this.heartsArray.push(heartContainer);
      }
      sprite.addChild(this.livesText);
      this.healthTitle = 'Health : ';
      healthLeft = Pigvane.Main.dude.health;
      this.healthText = this.game.add.bitmapText(0, 30, this.healthTitle + healthLeft, {
        font: '28px pixelFont'
      });
      sprite.addChild(this.healthText);
      sprite.cameraOffset.x = 10;
      sprite.cameraOffset.y = 10;
    }

    HealthOverlay.prototype.update = function() {
      var healthLeft;
      healthLeft = Pigvane.Main.dude.health;
      return this.healthText.setText(this.healthTitle + healthLeft);
    };

    HealthOverlay.prototype.removeLife = function() {
      var toDestroy;
      toDestroy = this.heartsArray.pop();
      return toDestroy.destroy();
    };

    return HealthOverlay;

  })();

}).call(this);

(function() {
  Pigvane.Classes.Level = (function() {
    function Level(game) {
      this.game = game;
    }

    Level.prototype.preload = function() {
      Pigvane.Main = this;
      this.gameWidth = 5;
      this.soundManager = new Phaser.SoundManager(this.game);
      this.soundManager.sfxJump = this.soundManager.add('sfx_jump', 0.5);
      this.soundManager.sfxGunshotPlayer = this.soundManager.add('sfx_gunshot_player', 0.25);
      this.soundManager.sfxGunshotEnemy = this.soundManager.add('sfx_gunshot_enemy', 0.25);
      this.soundManager.sfxDeathScream = this.soundManager.add('sfx_death_scream', 1);
      this.soundManager.sfxCollectable = this.soundManager.add('sfx_collectable', 0.5);
      this.doSound();
      this.config = {};
      this.setVariables();
      this.background = this.game.add.sprite(0, 0, this.config.background);
      this.background.fixedToCamera = true;
      this.map = this.game.add.tilemap(this.config.tilemap);
      this.tileset = this.game.add.tileset(this.config.tileset);
      this.initCollisions();
      this.bgScroll = this.game.add.tileSprite(0, 0, 500 * 32, 1024, this.config.bgScroll1);
      this.bgScroll.tilePosition.x = 0;
      this.bgScroll.tilePosition.y = -100;
      this.bgbgScroll = this.game.add.tileSprite(0, 0, 500 * 32, 1024, this.config.bgScroll2);
      this.bgbgScroll.tilePosition.x = 0;
      this.bgbgScroll.tilePosition.y = -200;
      this.repositionParallax();
      this.mainLayer = this.game.add.tilemapLayer(0, 0, 896, 672, this.tileset, this.map, 0);
      this.mainLayer.resizeWorld();
      this.game.stage.backgroundColor = "#222034";
      this.dude = new Pigvane.Classes.Dude(this.game, 100, 400);
      this.game.add.existing(this.dude);
      this.npcController = new Pigvane.Classes.NPCController(this.game);
      this.dialog = new Pigvane.Classes.Dialog(this.game);
      this.bullets = this.game.add.group();
      this.bullets.createMultiple(200, 'bullet');
      this.bullets.setAll('anchor.x', 0.5);
      this.bullets.setAll('anchor.y', 0.5);
      this.bullets.setAll('outOfBoundsKill', true);
      this.bullets.forEach(function(obj) {
        obj.animations.add('shoot', [0, 1, 2, 3]);
        return obj.animations.add('repeat', [2, 3]);
      });
      this.enemyBullets = this.game.add.group();
      this.enemyBullets.createMultiple(20, 'enemyBullet');
      this.enemyBullets.setAll('anchor.x', 0.5);
      this.enemyBullets.setAll('anchor.y', 0.5);
      this.enemyBullets.setAll('outOfBoundsKill', true);
      this.fgLayer = this.game.add.tilemapLayer(0, 0, 896, 672, this.tileset, this.map, 1);
      this.overlay = this.game.add.sprite(0, 0, 'scanlines');
      this.overlay.fixedToCamera = true;
      this.vignette = this.game.add.sprite(0, 0, this.config.vignette);
      this.vignette.fixedToCamera = true;
      this.healthBar = new Pigvane.Classes.HealthOverlay(this.game);
      this.game.world.camera.follow(this.dude, 1);
      return this.subPreload();
    };

    Level.prototype.update = function() {
      if (this.dude.x > this.config.nextLeveLX) {
        console.log('Hey');
        Pigvane.levelController.nextLevelIndex = Pigvane.levelController.currentLevelIndex + 1;
        this.fadeOut();
      }
      if ((Pigvane.Main.dlc != null) && this.dude.x > 6240) {
        Pigvane.Main.dlc.popup();
      }
      this.game.physics.overlap(this.enemyBullets, this.dude, this.dude.hitByNPC);
      return this.npcController.update();
    };

    Level.prototype.nextState = function() {
      return Pigvane.levelController.changeToLevel();
    };

    Level.prototype.fadeOut = function() {
      return Pigvane.levelController.changeToLevel();
    };

    Level.prototype.envHit = function(obj1, obj2) {
      return obj1.kill();
    };

    return Level;

  })();

}).call(this);

(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Pigvane.Classes.LevelCandy = (function(_super) {
    __extends(LevelCandy, _super);

    function LevelCandy(game) {
      this.game = game;
      LevelCandy.__super__.constructor.call(this, this.game);
    }

    LevelCandy.prototype.subPreload = function() {
      this.npcController.npcs.add(new Pigvane.Classes.NPCSpecial(this.game, 448, 512, 'npc_candy_crusher', 8, 'crusher_kill', 'crusher_help', 'candy_crusher'));
      this.npcController.npcs.add(new Pigvane.Classes.NPCSpecial(this.game, 1312, 512, 'npc_kitty', 2, 'cat_kill', 'cat_help', 'cake_cat'));
      this.npcController.npcs.add(new Pigvane.Classes.NPCSpecial(this.game, 3456, 320, 'npc_fruit_ninja', 2, 'ninja_kill', 'ninja_help', 'fruit_ninja'));
      return this.npcController.npcs.add(new Pigvane.Classes.NPCSpecial(this.game, 4416, 288, 'npc_angry_pig', 2, 'sick_pig_help', 'sick_pig_help', 'angry_pig'));
    };

    LevelCandy.prototype.doSound = function() {
      this.soundManager.music = this.game.add.audio('circus_music', 0.5, true);
      return this.soundManager.music.play();
    };

    LevelCandy.prototype.spawnRandomNPCs = function() {
      var i, _i, _results;
      _results = [];
      for (i = _i = 0; _i < 100; i = ++_i) {
        _results.push(this.npcController.npcs.add(new Pigvane.Classes.NPC(this.game, this.game.world.randomX, 10, 'hat_npc')));
      }
      return _results;
    };

    LevelCandy.prototype.setVariables = function() {
      this.config.background = 'candy-bg';
      this.config.tilemap = 'candy-tm';
      this.config.tileset = 'candy-ts';
      this.config.bgScroll1 = 'candy-bgScroll1';
      this.config.bgScroll2 = 'candy-bgScroll2';
      this.config.nextLeveLX = 9600;
      return this.config.vignette = "candy-vignette";
    };

    LevelCandy.prototype.repositionParallax = function() {
      this.bgScroll.tilePosition.y = 0;
      return this.bgbgScroll.tilePosition.y = 0;
    };

    LevelCandy.prototype.initCollisions = function() {
      return this.tileset.setCollisionRange(0, 30, true, true, true, true);
    };

    return LevelCandy;

  })(Pigvane.Classes.Level);

}).call(this);

(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Pigvane.Classes.LevelCity = (function(_super) {
    __extends(LevelCity, _super);

    function LevelCity(game) {
      this.game = game;
      LevelCity.__super__.constructor.call(this, this.game);
    }

    LevelCity.prototype.subPreload = function() {
      this.spawnRandomNPCs();
      this.npcController.npcs.add(new Pigvane.Classes.NPCSpecial(this.game, 3200, 384, 'npc_oldman', 4, 'old_man_kill', 'old_man_help', 'old_man'));
      this.npcController.npcs.add(new Pigvane.Classes.NPCSpecial(this.game, 4192, 160, 'npc_pig_girl', 2, 'pig_owner_kill', 'pig_owner_help', 'girl_with_pig'));
      this.npcController.npcs.add(new Pigvane.Classes.NPCSpecial(this.game, 512, 512, 'npc_monk', 2, 'monk_kill', 'monk_help', 'monk'));
      this.npcController.npcs.add(new Pigvane.Classes.NPCSpecial(this.game, 5568, 288, 'npc_ice_cream_girl', 2, 'kid_kill', 'kid_help', 'ice_cream_kid'));
      return Pigvane.Main.dlc = new Pigvane.Classes.DLC(this.game);
    };

    LevelCity.prototype.doSound = function() {
      this.soundManager.music = this.game.add.audio('city_music', 0.5, true);
      return this.soundManager.music.play();
    };

    LevelCity.prototype.repositionParallax = function() {};

    LevelCity.prototype.spawnRandomNPCs = function() {
      var i, _i, _results;
      _results = [];
      for (i = _i = 0; _i < 50; i = ++_i) {
        _results.push(this.npcController.npcs.add(new Pigvane.Classes.NPC(this.game, this.game.world.randomX, 400, 'hat_npc')));
      }
      return _results;
    };

    LevelCity.prototype.repositionParallax = function() {};

    LevelCity.prototype.setVariables = function() {
      this.config.background = 'city-bg';
      this.config.tilemap = 'city-tm';
      this.config.tileset = 'city-ts';
      this.config.bgScroll1 = 'city-bgScroll1';
      this.config.bgScroll2 = 'city-bgScroll2';
      this.config.nextLeveLX = 8200;
      return this.config.vignette = "city-vignette";
    };

    LevelCity.prototype.initCollisions = function() {
      return this.tileset.setCollisionRange(0, 8, true, true, true, true);
    };

    return LevelCity;

  })(Pigvane.Classes.Level);

}).call(this);

(function() {
  Pigvane.States.Main = (function() {
    function Main(game) {
      this.game = game;
      Pigvane.levelController = this;
      this.currentLevelIndex = 1;
      this.nextLevelIndex = 1;
    }

    Main.prototype.preload = function(game) {
      this.game = game;
      this.game.state.add('City', Pigvane.Classes.LevelCity, false);
      this.game.state.add('Candy', Pigvane.Classes.LevelCandy, false);
      this.game.state.add('End', Pigvane.Classes.End);
      return this.loadLevel();
    };

    Main.prototype.update = function() {
      if (this.currentLevel != null) {
        return this.currentLevel.update();
      }
    };

    Main.prototype.loadLevel = function() {
      switch (this.currentLevelIndex) {
        case 0:
          this.game.state.start('City');
          return Pigvane.Main.achievements = new Pigvane.Classes.Achievements(this.game);
        case 1:
          return this.game.state.start('Candy');
        case 2:
          return this.game.state.start('End');
      }
    };

    Main.prototype.changeToLevel = function() {
      this.currentLevelIndex = this.nextLevelIndex;
      return this.loadLevel();
    };

    return Main;

  })();

}).call(this);

(function() {
  Pigvane.States.MainMenu = (function() {
    function MainMenu(game) {
      this.game = game;
    }

    MainMenu.prototype.preload = function() {
      this.logo = this.add.sprite(0, 100, 'logo');
      this.logo.animations.add('dropthebass', [0, 1]);
      this.logo.animations.play('dropthebass', 2, true);
      return this.restartText = this.game.add.bitmapText(300, 600, 'Press Enter to Play', {
        'font': '30px pixelFont',
        'fill': 'white'
      });
    };

    MainMenu.prototype.update = function() {
      if (this.input.keyboard.isDown(13)) {
        if (this.fadedOut == null) {
          this.fadedOut = true;
          return this.fadeOut();
        }
      }
    };

    MainMenu.prototype.fadeOut = function() {
      var tween;
      tween = this.add.tween(this.restartText).to({
        alpha: 0
      }, 1000, Phaser.Easing.Linear.None, true);
      return tween.onComplete.add(this.startGame, this);
    };

    MainMenu.prototype.startGame = function() {
      return this.game.state.start('Main');
    };

    return MainMenu;

  })();

}).call(this);

(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Pigvane.Classes.NPC = (function(_super) {
    __extends(NPC, _super);

    function NPC(game, x, y, name) {
      this.game = game;
      NPC.__super__.constructor.call(this, this.game, x, y, name);
      this.anchor.setTo(0.5, 0.5);
      this.addAnimations();
      this.facing = 'left';
      this.body.gravity.y = 10;
      this.health = 3;
      this.updateTimer = 0;
      this.gunDuration = 0;
    }

    NPC.prototype.addAnimations = function() {
      this.animations.add('walk', [0, 1, 2, 3]);
      return this.animations.play('walk', 2, true);
    };

    NPC.prototype.update = function() {
      this.game.physics.collide(this, Pigvane.Main.mainLayer);
      if (this.game.time.now > this.updateTimer) {
        this.body.velocity.x = this.game.rnd.integerInRange(-20, 20);
        this.animations.play('walk', 2, true);
        if (this.body.velocity.x < 0) {
          this.scale.x = -1;
          this.facing = 'left';
        } else {
          this.scale.x = 1;
          this.facing = 'right';
        }
        if (Math.abs(this.body.x - Pigvane.Main.dude.x) < 200) {
          this.body.velocity.x = 0;
          this.animations.stop();
          this.animations.frame = 4;
          this.gunDuration++;
          if (this.body.x - Pigvane.Main.dude.x > 0) {
            this.scale.x = -1;
            this.facing = 'left';
          } else {
            this.scale.x = 1;
            this.facing = 'right';
          }
          if (this.gunDuration > 1) {
            this.fire();
            Pigvane.Main.soundManager.sfxGunshotEnemy.play();
          }
        } else {
          this.gunDuration = 0;
        }
        return this.updateTimer = this.game.time.now + this.game.rnd.integerInRange(40, 60) * 100;
      }
    };

    NPC.prototype.fire = function() {
      var bullet, callback;
      bullet = Pigvane.Main.enemyBullets.getFirstExists(false);
      if (bullet) {
        bullet.reset(this.x, this.y);
        bullet.animations.frame = 1;
        callback = function() {
          bullet.animations.stop();
          bullet.animations.play('repeat', 4, true);
          return bullet.animations.frame = bullet.x % 2 === 0 ? 2 : 3;
        };
        setTimeout(callback, 17);
        if (this.facing === 'right') {
          bullet.body.velocity.x = 1000;
        } else if (this.facing === 'left') {
          bullet.body.velocity.x = -1000;
        }
        bullet.body.velocity.x += this.game.rnd.integerInRange(-100, 100);
        return bullet.body.velocity.y += this.game.rnd.integerInRange(-40, 40);
      }
    };

    NPC.prototype.hit = function() {
      if (this.health > 0) {
        this.health -= 1;
        if (this.health <= 0) {
          return this.die();
        }
      }
    };

    NPC.prototype.die = function() {
      this.kill();
      this.destroy();
      Pigvane.Main.dude.kills += 1;
      return Pigvane.Main.dude.aggro += 1;
    };

    return NPC;

  })(Phaser.Sprite);

}).call(this);

(function() {
  Pigvane.Classes.NPCController = (function() {
    function NPCController(game) {
      this.game = game;
      this.npcs = this.game.add.group();
      this.npcDialogBoxes = this.game.add.group();
    }

    NPCController.prototype.update = function() {
      this.game.physics.overlap(Pigvane.Main.bullets, this.npcs, this.collisionHandler);
      return this.game.physics.overlap(Pigvane.Main.dude, this.npcDialogBoxes, this.dialogHandler);
    };

    NPCController.prototype.collisionHandler = function(obj1, obj2) {
      obj2.hit();
      if (obj2.health > 0) {
        return obj1.kill();
      }
    };

    NPCController.prototype.dialogHandler = function(obj1, obj2) {
      return obj2.initateDialog();
    };

    return NPCController;

  })();

}).call(this);

(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Pigvane.Classes.NPCDialogBox = (function(_super) {
    __extends(NPCDialogBox, _super);

    function NPCDialogBox(game, x, y, npc) {
      this.game = game;
      this.npc = npc;
      NPCDialogBox.__super__.constructor.call(this, this.game, x, y);
      this.width = this.npc.width * 2;
      this.height = this.npc.height;
      this.anchor.setTo(0.5, 0.5);
      this.body.collideWorldBounds = true;
      this.body.gravity.y = 10;
    }

    NPCDialogBox.prototype.update = function() {
      return this.game.physics.collide(this, Pigvane.Main.mainLayer);
    };

    NPCDialogBox.prototype.initateDialog = function() {
      if (this.game.input.keyboard.isDown(Phaser.Keyboard.C)) {
        return this.npc.talk();
      }
    };

    return NPCDialogBox;

  })(Phaser.Sprite);

}).call(this);

(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Pigvane.Classes.NPCSpecial = (function(_super) {
    __extends(NPCSpecial, _super);

    function NPCSpecial(game, x, y, name, numberFrames, deathAchievement, helpAchievement, dialog) {
      this.game = game;
      this.numberFrames = numberFrames;
      this.deathAchievement = deathAchievement;
      this.helpAchievement = helpAchievement;
      this.dialog = dialog;
      NPCSpecial.__super__.constructor.call(this, this.game, x, y, name);
      Pigvane.Main.npcController.npcDialogBoxes.add(new Pigvane.Classes.NPCDialogBox(this.game, x, y, this));
      this.talking = false;
      this.willTalk = true;
    }

    NPCSpecial.prototype.update = function() {
      return this.game.physics.collide(this, Pigvane.Main.mainLayer);
    };

    NPCSpecial.prototype.die = function() {
      Pigvane.Main.dude.specialKills += 1;
      if (this.deathAchievement != null) {
        Pigvane.Main.achievements.grant(this.deathAchievement);
        return this.destroy();
      }
    };

    NPCSpecial.prototype.talk = function() {
      var response;
      if ((this.dialog != null) && !this.talking && this.willTalk) {
        this.talking = true;
        return response = Pigvane.Main.dialog.popup(this.dialog, this);
      }
    };

    NPCSpecial.prototype.addAnimations = function() {
      var _i, _ref, _results;
      this.animations.add('walk', (function() {
        _results = [];
        for (var _i = 0, _ref = this.numberFrames; 0 <= _ref ? _i < _ref : _i > _ref; 0 <= _ref ? _i++ : _i--){ _results.push(_i); }
        return _results;
      }).apply(this));
      return this.animations.play('walk', 2, true);
    };

    NPCSpecial.prototype.sendResponse = function(option) {
      this.talking = false;
      this.willTalk = false;
      switch (option) {
        case '1':
          if (this.helpAchievement != null) {
            Pigvane.Main.achievements.grant(this.helpAchievement);
          }
          return Pigvane.Main.dude.helps += 1;
        case '2':
          return Pigvane.Main.dude.ignores += 1;
        case '3':
          return this.die();
        case 'reset':
          return this.willTalk = true;
      }
    };

    return NPCSpecial;

  })(Pigvane.Classes.NPC);

}).call(this);

(function() {
  Pigvane.States.Preloader = (function() {
    function Preloader(game) {
      this.game = game;
    }

    Preloader.prototype.preload = function() {
      this.preloadBar = this.add.sprite(128, 296, 'preload');
      this.load.setPreloadSprite(this.preloadBar);
      this.game.load.tilemap('city-tm', 'res/city-level.json', null, Phaser.Tilemap.TILED_JSON);
      this.game.load.tileset('city-ts', 'res/tiles-large.png', 32, 32);
      this.game.load.image('city-bg', 'res/coolbackestround.png');
      this.game.load.image('city-bgScroll1', 'res/bg1-large.png');
      this.game.load.image('city-bgScroll2', 'res/bg2-large.png');
      this.game.load.tilemap('candy-tm', 'res/candyland-level.json', null, Phaser.Tilemap.TILED_JSON);
      this.game.load.tileset('candy-ts', 'res/candylandtiles-large.png', 32, 32);
      this.game.load.image('candy-bg', 'res/candybase-large.png');
      this.game.load.image('candy-bgScroll1', 'res/candycanes3-large.png');
      this.game.load.image('candy-bgScroll2', 'res/candycanes1-large.png');
      this.game.load.spritesheet('lives', 'res/heart-large.png', 32, 32);
      this.game.load.image('achievement_background', 'res/achievement.png');
      this.game.load.image('dialog', 'res/dialogue.png');
      this.game.load.spritesheet('dude', 'res/testwalking-large.png', 32, 32);
      this.game.load.spritesheet('hat_npc', 'res/npc6-large.png', 32, 32);
      this.game.load.image('scanlines', 'res/scanlines.png');
      this.game.load.image('city-vignette', 'res/vignette.png');
      this.game.load.image('candy-vignette', 'res/vignette.png');
      this.game.load.spritesheet('bullet', 'res/bullet-large.png', 32, 32);
      this.game.load.spritesheet('enemyBullet', 'res/bullet-large.png', 32, 32);
      this.game.load.image('achievement_3_lives', 'res/3lives.png');
      this.game.load.image('achievement_cats_can_play', 'res/catCanPlay.png');
      this.game.load.image('achievement_city_complete', 'res/CityComplete.png');
      this.game.load.image('achievement_copyright_violation', 'res/Copyright Violation.png');
      this.game.load.image('achievement_dlc', 'res/DLC.png');
      this.game.load.image('achievement_first_steps', 'res/first steps.png');
      this.game.load.image('achievement_first_blood', 'res/FirstBlood.png');
      this.game.load.image('achievement_help_candy_crusher', 'res/HelpCandyCrusher.png');
      this.game.load.image('achievement_help_cat', 'res/HelpCat.png');
      this.game.load.image('achievement_help_fruit_ninja', 'res/HelpFruitNinja.png');
      this.game.load.image('achievement_help_kid', 'res/HelpKid.png');
      this.game.load.image('achievement_help_monk', 'res/HelpMonk.png');
      this.game.load.image('achievement_help_old_man', 'res/HelpOldMan.png');
      this.game.load.image('achievement_help_pig_owner', 'res/HelpPigOwner.png');
      this.game.load.image('achievement_help_sick_pig', 'res/HelpSickPig.png');
      this.game.load.image('achievement_kill_candy_crusher', 'res/KillCandyCrusher.png');
      this.game.load.image('achievement_kill_cat', 'res/KillCat.png');
      this.game.load.image('achievement_kill_fruit_ninja', 'res/KillFruitNinja.png');
      this.game.load.image('achievement_kill_kid', 'res/KillKid.png');
      this.game.load.image('achievement_kill_monk', 'res/KillMonk.png');
      this.game.load.image('achievement_kill_old_man', 'res/KillOldMan.png');
      this.game.load.image('achievement_kill_pig_owner', 'res/KillPigOwner.png');
      this.game.load.image('achievement_kill_sick_pig', 'res/KillSickPig.png');
      this.game.load.image('achievement_sunshine_rainbows', 'res/sunshineRainbows.png');
      this.game.load.image('achievement_finish_wind', 'res/concordance.png');
      this.game.load.image('achievement_first_free', 'res/FirstOneFree.png');
      this.game.load.image('achievement_finish_pig', 'res/greed.png');
      this.game.load.image('achievement_finish_human', 'res/Loneliness.png');
      this.game.load.image('achievement_pacifist', 'res/pacifist.png');
      this.game.load.spritesheet('npc_oldman', 'res/oldman-large.png', 32, 32);
      this.game.load.spritesheet('npc_pig_girl', 'res/piggirl-large.png', 64, 32);
      this.game.load.spritesheet('npc_monk', 'res/monk-large.png', 32, 32);
      this.game.load.spritesheet('npc_ice_cream_girl', 'res/icecreamgirl-large.png', 32, 32);
      this.game.load.spritesheet('npc_candy_crusher', 'res/candycrusher-large.png', 64, 32);
      this.game.load.spritesheet('npc_kitty', 'res/kitty-large.png', 32, 32);
      this.game.load.spritesheet('npc_fruit_ninja', 'res/fruitninja-large.png', 32, 32);
      this.game.load.spritesheet('npc_angry_pig_green', 'res/angrypig_green-large.png', 32, 32);
      this.game.load.audio('circus_music', 'res/circus_music.mp3');
      this.game.load.audio('city_music', 'res/city_music_1.mp3');
      this.game.load.audio('sfx_jump', 'res/Jump.mp3');
      this.game.load.audio('sfx_gunshot_player', 'res/PlayerGunshot.mp3');
      this.game.load.audio('sfx_gunshot_enemy', 'res/EnemyGunshot.mp3');
      this.game.load.audio('sfx_death_scream', 'res/DeathScream.mp3');
      this.game.load.audio('sfx_collectable', 'res/Collectable.mp3');
      this.game.load.bitmapFont('pixelfont', 'res/pixelFont.png', 'res/pixelFont.xml');
      return this.game.load.spritesheet('logo', 'res/title-large.png', 896, 256);
    };

    Preloader.prototype.create = function() {
      var tween;
      tween = this.add.tween(this.preloadBar).to({
        alpha: 0
      }, 1000, Phaser.Easing.Linear.None, true);
      return tween.onComplete.add(this.startMainMenu, this);
    };

    Preloader.prototype.startMainMenu = function() {
      return this.game.state.start('MainMenu');
    };

    return Preloader;

  })();

}).call(this);

(function() {
  Pigvane.States.Restart = (function() {
    function Restart(game) {
      this.game = game;
    }

    Restart.prototype.preload = function() {
      this.game.stage.backgroundColor = '#000';
      this.text = this.game.add.bitmapText(200, 250, 'You Died', {
        'font': '120px pixelFont',
        'fill': 'white'
      });
      this.restartText = this.game.add.bitmapText(300, 600, 'Please click to restart', {
        'font': '30px pixelFont',
        'fill': 'white'
      });
      return this.input.onDown.addOnce(this.fadeOut, this);
    };

    Restart.prototype.fadeOut = function() {
      var tween;
      this.add.tween(this.text).to({
        alpha: 0
      }, 2000, Phaser.Easing.Linear.None, true);
      tween = this.add.tween(this.restartText).to({
        alpha: 0
      }, 2000, Phaser.Easing.Linear.None, true);
      return tween.onComplete.add(this.restart, this);
    };

    Restart.prototype.restart = function() {
      return this.game.state.start('Main');
    };

    return Restart;

  })();

}).call(this);

(function() {
  var height, width;

  width = 896;

  height = 672;

  Pigvane.game = new Phaser.Game(width, height, Phaser.CANVAS, 'game');

  Pigvane.game.state.add('Boot', Pigvane.States.Boot, true);

  Pigvane.game.state.add('Preloader', Pigvane.States.Preloader, false);

  Pigvane.game.state.add('MainMenu', Pigvane.States.MainMenu, false);

  Pigvane.game.state.add('Main', Pigvane.States.Main, false);

  Pigvane.game.state.add('Restart', Pigvane.States.Restart, false);

}).call(this);
